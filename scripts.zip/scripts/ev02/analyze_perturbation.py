# analyze_perturbation.py
import os, glob, argparse
import numpy as np
import pandas as pd
from typing import Tuple
from math import isnan

def overshoot_ringdown(E: np.ndarray, t: np.ndarray, t_step: int, dur: int, pct: float=0.05) -> Tuple[float, float, float]:
    pre = E[t < t_step]
    post = E[(t >= t_step)]
    if pre.size == 0 or post.size == 0:
        return np.nan, np.nan, np.nan
    E_ss = float(np.median(pre))  # estado estacionario pre-escalón
    peak = float(np.max(post))
    ov = peak - E_ss
    if ov <= 0:
        return ov, 0.0, np.nan
    thr = E_ss + pct * ov
    # ringdown: primer t>t_step tal que E(t) <= thr después del pico
    after_peak_idx = np.where(post >= peak - 1e-12)[0]
    start_idx = after_peak_idx[0] if after_peak_idx.size>0 else 0
    t_post = t[t >= t_step]
    rd = np.nan
    for i in range(start_idx, len(post)):
        if post[i] <= thr:
            rd = float(t_post[i] - t_step)
            break
    # AR(1) en ventana [t_step+dur, t_step+2*dur]
    w_start, w_end = t_step + dur, t_step + 2*dur
    w = (t >= w_start) & (t < w_end)
    ar1 = np.nan
    if np.sum(w) >= 3:
        x = E[w].astype(float)
        x_t, x_l = x[1:], x[:-1]
        x_t -= x_t.mean(); x_l -= x_l.mean()
        ar1 = float(np.dot(x_l, x_t) / (np.dot(x_l, x_l) + 1e-12))
    return ov, rd, ar1

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tick_dir", default="outputs/tick_data")
    ap.add_argument("--out_csv", default="outputs/summary/aim3_perturbation.csv")
    ap.add_argument("--t_step", type=int, default=300)
    ap.add_argument("--dur", type=int, default=50)
    args = ap.parse_args()

    rows = []
    for path in glob.glob(os.path.join(args.tick_dir, "*.csv")):
        df = pd.read_csv(path)
        if "tick" not in df or "E_env" not in df: 
            continue
        regime = df.get("regime", [None])[0]
        policy = df.get("policy", [None])[0]
        arch   = df.get("architecture", [None])[0]
        seed   = int(df.get("seed", [0])[0])

        t = df["tick"].to_numpy()
        E = df["E_env"].to_numpy()
        ov, rd, ar1p = overshoot_ringdown(E, t, t_step=args.t_step, dur=args.dur)

        rows.append({
            "regime": regime, "policy": policy, "architecture": arch, "seed": seed,
            "overshoot": ov, "ringdown_time": rd, "AR1_post": ar1p
        })
    os.makedirs(os.path.dirname(args.out_csv), exist_ok=True)
    out = pd.DataFrame(rows)
    out.to_csv(args.out_csv, index=False)

    # Resumen por régimen/política
    if not out.empty:
        summ = out.groupby(["regime","policy"]).agg(["median","mean"])
        print("\n=== AIM-3 summary (median/mean) ===")
        print(summ[["overshoot","ringdown_time","AR1_post"]].round(3))

if __name__ == "__main__":
    main()
