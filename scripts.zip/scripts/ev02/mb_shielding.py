# mb_shielding.py
import os, glob, argparse
import numpy as np
import pandas as pd
from typing import Dict, Tuple
try:
    import pingouin as pg
except Exception:
    pg = None

def partial_corr(x, y, z1, z2) -> float:
    if pg is not None:
        df = pd.DataFrame({"x":x, "y":y, "z1":z1, "z2":z2}).dropna()
        if len(df) < 8: return np.nan
        r = pg.partial_corr(data=df, x="x", y="y", covar=["z1","z2"], method="pearson")
        return float(r["r"].iloc[0])
    # fallback: regresiones lineales y correlación de residuos
    def resid(a, cov):
        A = np.column_stack([np.ones(len(a)), cov])
        w, *_ = np.linalg.lstsq(A, a, rcond=None)
        return a - A.dot(w)
    M = np.column_stack([z1, z2])
    rx = resid(np.asarray(x, float), M)
    ry = resid(np.asarray(y, float), M)
    if np.std(rx) < 1e-12 or np.std(ry) < 1e-12: return np.nan
    return float(np.corrcoef(rx, ry)[0,1])

def alive_window(df: pd.DataFrame, N: int, tail: int=120) -> pd.DataFrame:
    ticks = df["tick"].to_numpy()
    alive = df["n_alive"].to_numpy()
    idx = np.where(alive < 0.5*N)[0]
    if len(idx) > 0:
        tstar = int(ticks[idx[0]])
        return df[(df["tick"] >= max(0, tstar-tail)) & (df["tick"] <= tstar)]
    if (df["n_alive"] > 0).any():
        last = int(df[df["n_alive"]>0]["tick"].max())
        return df[(df["tick"] >= max(0, last-tail)) & (df["tick"] <= last)]
    return df.tail(tail)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tick_dir", default="outputs/tick_data")
    ap.add_argument("--out_csv", default="outputs/summary/aim4_mbshielding.csv")
    ap.add_argument("--N", type=int, default=40)
    ap.add_argument("--tail", type=int, default=120)
    ap.add_argument("--per_agent_dir", default="outputs/agents", help="OPCIONAL: CSVs con series por agente")
    args = ap.parse_args()

    rows = []
    tick_files = sorted(glob.glob(os.path.join(args.tick_dir, "*.csv")))
    for path in tick_files:
        df = pd.read_csv(path)
        regime = df.get("regime", [None])[0]
        policy = df.get("policy", [None])[0]
        arch   = df.get("architecture", [None])[0]
        seed   = int(df.get("seed", [0])[0])

        # Ventana viva
        d = alive_window(df, args.N, tail=args.tail)

        # Poblacional (fallback)
        I = d["mean_gamma"].to_numpy()
        S = d["E_env"].to_numpy()
        A = (d["total_demand"] * d["G_env"]).to_numpy()
        S_star = S  # aquí usamos S* = S (si tienes filtro/derivada, sustitúyelo)
        rho_pop = partial_corr(I, S_star, S, A)

        # Per-agente (si existe carpeta con series individuales)
        rho_med = np.nan
        count_ok = 0
        agent_files = sorted(glob.glob(os.path.join(args.per_agent_dir, f"*{regime}_{policy}_seed{seed}_agent*.csv")))
        if agent_files:
            rhos = []
            for apath in agent_files:
                adf = pd.read_csv(apath)
                adf = adf[adf["tick"].isin(d["tick"])]
                if {"gamma","u"}.issubset(adf.columns):
                    r = partial_corr(adf["gamma"].to_numpy(), S_star[:len(adf)], S[:len(adf)], (adf["u"].to_numpy()*d["G_env"].to_numpy()[:len(adf)]))
                    rhos.append(r)
            if rhos:
                rho_med = float(np.nanmedian(rhos)); count_ok = len(rhos)

        rows.append({
            "regime": regime, "policy": policy, "architecture": arch, "seed": seed,
            "rho_pop": rho_pop, "rho_agent_median": rho_med, "n_agents_series": count_ok
        })

    os.makedirs(os.path.dirname(args.out_csv), exist_ok=True)
    out = pd.DataFrame(rows)
    out.to_csv(args.out_csv, index=False)

    # Resumen y prueba Wilcoxon si hay pares APP vs VOFF
    print("\n=== AIM-4 (resumen) ===")
    for reg in sorted(out["regime"].dropna().unique()):
        sub = out[out["regime"]==reg]
        grp = sub.groupby("policy")["rho_pop"].median()
        print(f"[{reg}] rho_pop median  VOFF={grp.get('VOFF', np.nan):.3f}  APP-Fixed={grp.get('APP-Fixed', np.nan):.3f}")
    print("Guardado:", args.out_csv)

if __name__ == "__main__":
    main()
