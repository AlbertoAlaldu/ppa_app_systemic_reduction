#!/usr/bin/env python3
import pandas as pd, numpy as np, matplotlib.pyplot as plt
from pathlib import Path

df = pd.read_csv("outputs/summary/aim12_all_metrics.csv")
reg_order = ["RE","RH","RC"]; metrics=[("var_E","Variance"),("rugosity","Rugosity"),("AR1","Autocorrelation")]

fig, axes = plt.subplots(1,3, figsize=(14,4), sharex=False)
for k,(m,label) in enumerate(metrics):
    ax = axes[k]
    xs, ys, cs = [], [], []
    for i,reg in enumerate(reg_order):
        for pol,color in [("VOFF","#f8a8a8"),("APP-Fixed","#a8c7f8")]:
            vals = df[(df.regime==reg)&(df.policy==pol)][m].dropna().values
            x = i + ( -0.12 if pol=="VOFF" else 0.12 )
            ax.scatter([x]*len(vals), vals, s=10, alpha=0.7, color=color, edgecolors="none")
            ax.errorbar(x, np.median(vals), yerr=[[np.median(vals)-np.percentile(vals,25)],
                                                  [np.percentile(vals,75)-np.median(vals)]],
                        fmt='_', lw=2, color="k")
    ax.set_xticks(range(len(reg_order))); ax.set_xticklabels(reg_order)
    ax.set_title(label)
fig.legend(handles=[plt.Line2D([0],[0], marker='o', color='w', label='VOFF', markerfacecolor='#f8a8a8', markersize=8),
                    plt.Line2D([0],[0], marker='o', color='w', label='APP', markerfacecolor='#a8c7f8', markersize=8)],
           loc="upper center", ncol=2, frameon=False)
plt.tight_layout(rect=[0,0,1,0.92])
Path("figures").mkdir(exist_ok=True)
plt.savefig("figures/fig2_stability_REAL.png", dpi=300)
print("[OK] figures/fig2_stability_REAL.png")
