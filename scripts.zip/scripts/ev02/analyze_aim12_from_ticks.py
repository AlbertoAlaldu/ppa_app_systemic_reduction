#!/usr/bin/env python3
import pandas as pd, numpy as np, glob, os
from pathlib import Path

# --- helpers ---
def shannon_entropy(counts):
    counts = np.asarray(counts, dtype=float)
    tot = counts.sum()
    if tot <= 0: return 0.0
    p = counts[counts > 0] / tot
    return float(-(p*np.log(p)).sum())

def alive_window(df, tail=60):
    if (df["n_alive"] > 0).any():
        last = int(df.loc[df["n_alive"]>0, "tick"].max())
        start = max(0, last - tail)
        return df[(df["tick"]>=start) & (df["tick"]<=last)].copy()
    # si todos murieron antes del primer tick útil, toma últimos tail
    return df.tail(tail).copy()

# thresholds por régimen (ajusta si tus configs difieren)
C_MAX = {"RE": 600, "RH": 150, "RC": 80}
GAMMA_MIN = 0.1
H_MAX = 1.0

def infer_deaths(df, regime):
    deaths = dict(gamma=0, h=0, C=0, B=0)
    if len(df) < 2: return deaths
    ticks = df["tick"].to_numpy()
    n = df["n_alive"].to_numpy()
    mg = df["mean_gamma"].to_numpy()
    mh = df["mean_h"].to_numpy()
    mC = df["mean_C"].to_numpy()
    Cmax = C_MAX.get(regime, 100)

    for i in range(1, len(df)):
        died = int(n[i-1] - n[i])
        if died <= 0: continue
        # estado justo después de la caída
        dist_g = mg[i] - GAMMA_MIN
        dist_h = H_MAX - mh[i]
        dist_C = Cmax - mC[i]
        # normaliza por umbral para comparar márgenes relativos
        margins = {
            "gamma": dist_g / max(GAMMA_MIN, 1e-9),
            "h":     dist_h / max(H_MAX, 1e-9),
            "C":     dist_C / max(Cmax, 1e-9)
        }
        cause = min(margins, key=margins.get)
        deaths[cause] += died
    return deaths

def ar1(x):
    x = np.asarray(x, dtype=float)
    if len(x) < 3 or np.std(x) == 0: return np.nan
    return float(np.corrcoef(x[:-1], x[1:])[0,1])

def main():
    tick_files = sorted(glob.glob("outputs/tick_data/*.csv"))
    if not tick_files:
        raise SystemExit("No encontré archivos en outputs/tick_data/*.csv")

    rows = []
    for path in tick_files:
        df = pd.read_csv(path)
        # meta desde columnas (más robusto que solo filename)
        regime = str(df["regime"].iloc[0])
        policy = str(df["policy"].iloc[0])
        arch   = str(df["architecture"].iloc[0])
        seed   = int(df["seed"].iloc[0])
        # ventana viva
        W = alive_window(df, tail=60)
        E = W["E_env"].to_numpy()

        varE = float(np.var(E)) if len(E)>1 else np.nan
        rug  = float(np.abs(np.diff(E)).sum()) if len(E)>1 else np.nan
        phi  = ar1(E)

        deaths = infer_deaths(df, regime)
        H = shannon_entropy([deaths["gamma"], deaths["h"], deaths["C"], deaths["B"]])

        last_alive = int(df.loc[df["n_alive"]>0, "tick"].max()) if (df["n_alive"]>0).any() else 0
        lifespan   = float(last_alive)  # en ticks; si quieres por-agente, divide entre N

        rows.append({
            "seed": seed, "regime": regime, "policy": policy, "architecture": arch,
            "var_E": varE, "rugosity": rug, "AR1": phi,
            "deaths_gamma": deaths["gamma"], "deaths_h": deaths["h"], "deaths_C": deaths["C"], "deaths_B": deaths["B"],
            "H_causes": H, "last_alive_tick": lifespan
        })

    out = pd.DataFrame(rows).sort_values(["regime","policy","seed"])
    os.makedirs("outputs/summary", exist_ok=True)
    out_path = "outputs/summary/aim12_all_metrics.csv"
    out.to_csv(out_path, index=False)

    # resumen rápido en consola
    print(f"[OK] Escribí: {out_path} ({len(out)} filas)\n")
    for reg in ["RE","RH","RC"]:
        subR = out[out["regime"]==reg]
        if subR.empty: continue
        print(f"== {reg} ==")
        for pol in ["VOFF","APP-Fixed"]:
            sub = subR[subR["policy"]==pol]
            if sub.empty: continue
            tot = sub[["deaths_gamma","deaths_h","deaths_C"]].sum()
            S = tot.sum()
            if S>0:
                pg = 100*tot["deaths_gamma"]/S
                ph = 100*tot["deaths_h"]/S
                pC = 100*tot["deaths_C"]/S
                print(f" {pol:9s}  deaths%  γ={pg:5.1f}  h={ph:5.1f}  C={pC:5.1f}   H={sub['H_causes'].mean():.3f}")
            print(f"             var(E)={sub['var_E'].mean():.4f}  rug={sub['rugosity'].mean():.4f}  AR1={sub['AR1'].mean():.3f}  life={sub['last_alive_tick'].mean():.1f}")

if __name__ == "__main__":
    main()
