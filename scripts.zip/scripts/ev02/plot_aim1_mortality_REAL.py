#!/usr/bin/env python3
import pandas as pd, numpy as np, matplotlib.pyplot as plt
from pathlib import Path

df = pd.read_csv("outputs/summary/aim12_all_metrics.csv")

# agregados por régimen/política
agg = (df.groupby(["regime","policy"])
         [["deaths_gamma","deaths_h","deaths_C","H_causes"]]
         .sum().reset_index())
# % por causa
tot = (agg[["deaths_gamma","deaths_h","deaths_C"]].sum(axis=1)).replace(0, np.nan)
for c in ["deaths_gamma","deaths_h","deaths_C"]:
    agg[c] = 100*agg[c]/tot

# plot 3 paneles + H de VOFF
fig = plt.figure(figsize=(14,4))
reg_order = ["RE","RH","RC"]
colors = dict(gamma="#c92525", h="#ff8c1a", C="#1fa64a")

for i,reg in enumerate(reg_order,1):
    ax = plt.subplot(1,4,i)
    sub = agg[agg["regime"]==reg].set_index("policy")
    for j,(label,col) in enumerate([("deaths_gamma","gamma"),("deaths_h","h"),("deaths_C","C")]):
        bottom_vals = sub[[k for k in ["deaths_gamma","deaths_h","deaths_C"]]].iloc[:,:j].sum(axis=1)
        ax.bar(["VOFF","APP"], sub[label], bottom=bottom_vals,
               color=colors[col], edgecolor="white", width=0.6)
    ax.set_title(reg, fontsize=16)
    ax.set_ylim(0,100); ax.set_ylabel("% Deaths" if i==1 else "")
    # H sobre VOFF
    H = df[(df.regime==reg)&(df.policy=="VOFF")]["H_causes"].mean()
    ax.text(0.06, 104, f"H={H:.2f}", fontsize=11)

ax = plt.subplot(1,4,4)
Hs = [df[(df.regime==r)&(df.policy=="VOFF")]["H_causes"].mean() for r in reg_order]
ax.bar(reg_order, Hs, color="#7aa6d6")
ax.set_title("D) Mortality Entropy (VOFF)", fontsize=14); ax.set_ylim(0,0.8); ax.set_ylabel("H(causes)")

plt.tight_layout()
Path("figures").mkdir(exist_ok=True)
plt.savefig("figures/fig1_mortality_partitioning_REAL.png", dpi=300)
print("[OK] figures/fig1_mortality_partitioning_REAL.png")
