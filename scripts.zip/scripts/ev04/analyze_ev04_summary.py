# analyze_ev04_summary.py
import os
import pandas as pd

# carpetas que ya generaste con el simulador
RUNS = [
    ("RE", "APP-Fixed", "outputs_EV04_RE_APP-Fixed/summary/all_metrics.csv"),
    ("RE", "VOFF",      "outputs_EV04_RE_VOFF/summary/all_metrics.csv"),
    ("RH", "APP-Fixed", "outputs_EV04_RH_APP-Fixed/summary/all_metrics.csv"),
    ("RH", "VOFF",      "outputs_EV04_RH_VOFF/summary/all_metrics.csv"),
    ("RC", "APP-Fixed", "outputs_EV04_RC_APP-Fixed/summary/all_metrics.csv"),
    ("RC", "VOFF",      "outputs_EV04_RC_VOFF/summary/all_metrics.csv"),
]

rows = []
for regime, policy, path in RUNS:
    if not os.path.exists(path):
        print(f"[AVISO] No encontré {path}, lo salto.")
        continue
    df = pd.read_csv(path)
    # cada csv trae una fila por seed → aquí promediamos por seed
    df["regime"] = regime
    df["policy"] = policy
    rows.append(df)

if not rows:
    raise SystemExit("No se pudo cargar ningún CSV. Revisa las rutas.")

all_df = pd.concat(rows, ignore_index=True)

# columnas que nos interesan del simulador
keep_cols = [
    "regime", "policy", "architecture",
    "var_ps", "p2p_ps", "rugosity", "cv_ps",
    "H_causes",
    "deaths_gamma", "deaths_h", "deaths_C", "deaths_B",
    "survival_rate", "mean_lifespan", "mean_V_tail",
    "convergence_tick",
]

# algunas versiones pueden no tener todas → filtrar las que existan
keep_cols = [c for c in keep_cols if c in all_df.columns]
all_df = all_df[keep_cols]

# agregamos por régimen+política (porque tienes varias seeds)
summary = (
    all_df
    .groupby(["regime", "policy"], as_index=False)
    .mean(numeric_only=True)
    .sort_values(["regime", "policy"])
)

print("\n===== RESUMEN EV-04 (promedio sobre seeds) =====\n")
print(summary.to_string(index=False, float_format=lambda x: f"{x:0.4f}"))

# guardamos
out_path = "ev04_all_metrics_summary.csv"
summary.to_csv(out_path, index=False)
print(f"\n✅ Guardado en: {out_path}")
