#!/usr/bin/env python3
"""
Análisis de Causalidad de Granger: E_env ↔ γ

Granger causality mide si la historia pasada de X mejora la predicción
de Y más allá de la historia de Y mismo.

Uso:
    python analyze_granger_causality.py \
        --app_agents path/to/APP/agents \
        --voff_agents path/to/VOFF/agents \
        --app_ticks path/to/APP/tick_data \
        --voff_ticks path/to/VOFF/tick_data \
        --regime RE \
        --output_dir granger_results
"""

import argparse
import glob
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from statsmodels.tsa.stattools import grangercausalitytests
from statsmodels.tsa.vector_ar.var_model import VAR
from scipy.stats import mannwhitneyu
import warnings
warnings.filterwarnings('ignore')

def prepare_series(agent_path, tick_path, min_length=60): # original 60
    """
    Prepara series temporales para análisis de Granger
    """
    # Cargar datos
    agent = pd.read_csv(agent_path)
    tick = pd.read_csv(tick_path)
    
    # Merge
    df = pd.merge(agent, tick[['tick', 'E_env']], on='tick', how='inner')
    df = df[df['alive'] == 1].copy()
    
    if len(df) < min_length:
        return None
    
    # Extraer series
    gamma = df['gamma'].values
    E_env = df['E_env'].values
    
    # Normalizar (importante para Granger)
    gamma = (gamma - np.mean(gamma)) / (np.std(gamma) + 1e-10)
    E_env = (E_env - np.mean(E_env)) / (np.std(E_env) + 1e-10)
    
    return gamma, E_env


def compute_granger_causality(x, y, max_lag=10):
    """
    Calcula causalidad de Granger en ambas direcciones
    
    Returns:
        gc_x_to_y: dict con p-values para X → Y
        gc_y_to_x: dict con p-values para Y → X
    """
    # Crear DataFrame con ambas series
    data_xy = pd.DataFrame({'y': y, 'x': x})
    data_yx = pd.DataFrame({'x': x, 'y': y})
    
    gc_results_x_to_y = {}
    gc_results_y_to_x = {}
    
    try:
        # X → Y (x granger-causa y?)
        gc_test_xy = grangercausalitytests(data_xy, max_lag, verbose=False)
        
        for lag in range(1, max_lag + 1):
            # Usar F-test
            p_value = gc_test_xy[lag][0]['ssr_ftest'][1]
            gc_results_x_to_y[lag] = p_value
        
        # Y → X (y granger-causa x?)
        gc_test_yx = grangercausalitytests(data_yx, max_lag, verbose=False)
        
        for lag in range(1, max_lag + 1):
            p_value = gc_test_yx[lag][0]['ssr_ftest'][1]
            gc_results_y_to_x[lag] = p_value
            
    except Exception as e:
        # Si falla, retornar None
        return None, None
    
    return gc_results_x_to_y, gc_results_y_to_x


def analyze_single_agent(agent_path, tick_path, max_lag=10):
    """
    Analiza un agente individual
    """
    series = prepare_series(agent_path, tick_path, min_length=60)
    
    if series is None:
        return None
    
    gamma, E_env = series
    
    # Granger causality
    gc_E_to_gamma, gc_gamma_to_E = compute_granger_causality(E_env, gamma, max_lag)
    
    if gc_E_to_gamma is None:
        return None
    
    # Encontrar mejor lag (menor p-value)
    best_lag_E_to_gamma = min(gc_E_to_gamma.items(), key=lambda x: x[1])
    best_lag_gamma_to_E = min(gc_gamma_to_E.items(), key=lambda x: x[1])
    
    return {
        'n_ticks': len(gamma),
        'gc_E_to_gamma_p': best_lag_E_to_gamma[1],
        'gc_E_to_gamma_lag': best_lag_E_to_gamma[0],
        'gc_gamma_to_E_p': best_lag_gamma_to_E[1],
        'gc_gamma_to_E_lag': best_lag_gamma_to_E[0],
        'gc_E_to_gamma_all': gc_E_to_gamma,
        'gc_gamma_to_E_all': gc_gamma_to_E
    }


def analyze_policy(agents_dir, ticks_dir, policy_name, max_lag=10):
    """
    Analiza todos los agentes de una política
    """
    agent_files = sorted(glob.glob(os.path.join(agents_dir, "*.csv")))
    
    if len(agent_files) == 0:
        print(f"⚠️  No se encontraron archivos en {agents_dir}")
        return []
    
    # Buscar tick_data
    tick_pattern = os.path.join(ticks_dir, "*.csv")
    tick_files = glob.glob(tick_pattern)
    
    if len(tick_files) == 0:
        print(f"⚠️  No se encontró tick_data")
        return []
    
    tick_path = tick_files[0]
    
    print(f"📊 Analizando {len(agent_files)} agentes de {policy_name}...")
    
    results = []
    for agent_path in agent_files:
        res = analyze_single_agent(agent_path, tick_path, max_lag=max_lag)
        if res is not None:
            res['policy'] = policy_name
            res['agent_file'] = os.path.basename(agent_path)
            results.append(res)
    
    print(f"   ✓ {len(results)} agentes analizados")
    
    return results


def plot_granger_results(df_app, df_voff, regime, output_dir):
    """
    Visualiza resultados de Granger causality
    """
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    
    # Panel 1: p-values E → γ
    ax = axes[0]
    data_app = -np.log10(df_app['gc_E_to_gamma_p'].values + 1e-300)
    data_voff = -np.log10(df_voff['gc_E_to_gamma_p'].values + 1e-300)
    
    bp = ax.boxplot([data_app, data_voff], positions=[1, 2], widths=0.6, patch_artist=True)
    bp['boxes'][0].set_facecolor('lightblue')
    bp['boxes'][1].set_facecolor('lightcoral')
    
    ax.axhline(-np.log10(0.05), color='red', linestyle='--', label='p=0.05', alpha=0.5)
    ax.set_xticks([1, 2])
    ax.set_xticklabels(['APP', 'VOFF'])
    ax.set_ylabel('-log₁₀(p-value)')
    ax.set_title(f'{regime}: Granger Causality\nE_env → γ')
    ax.legend()
    ax.grid(alpha=0.3, axis='y')
    
    # Panel 2: p-values γ → E
    ax = axes[1]
    data_app = -np.log10(df_app['gc_gamma_to_E_p'].values + 1e-300)
    data_voff = -np.log10(df_voff['gc_gamma_to_E_p'].values + 1e-300)
    
    bp = ax.boxplot([data_app, data_voff], positions=[1, 2], widths=0.6, patch_artist=True)
    bp['boxes'][0].set_facecolor('lightblue')
    bp['boxes'][1].set_facecolor('lightcoral')
    
    ax.axhline(-np.log10(0.05), color='red', linestyle='--', label='p=0.05', alpha=0.5)
    ax.set_xticks([1, 2])
    ax.set_xticklabels(['APP', 'VOFF'])
    ax.set_ylabel('-log₁₀(p-value)')
    ax.set_title(f'{regime}: Granger Causality\nγ → E_env')
    ax.legend()
    ax.grid(alpha=0.3, axis='y')
    
    # Panel 3: Ratio de causalidad
    ax = axes[2]
    
    # Porcentaje de agentes con causalidad significativa
    sig_E_gamma_app = (df_app['gc_E_to_gamma_p'] < 0.05).sum() / len(df_app) * 100
    sig_E_gamma_voff = (df_voff['gc_E_to_gamma_p'] < 0.05).sum() / len(df_voff) * 100
    sig_gamma_E_app = (df_app['gc_gamma_to_E_p'] < 0.05).sum() / len(df_app) * 100
    sig_gamma_E_voff = (df_voff['gc_gamma_to_E_p'] < 0.05).sum() / len(df_voff) * 100
    
    x = np.arange(2)
    width = 0.35
    
    ax.bar(x - width/2, [sig_E_gamma_app, sig_gamma_E_app], width, 
           label='APP', color='lightblue', edgecolor='black')
    ax.bar(x + width/2, [sig_E_gamma_voff, sig_gamma_E_voff], width,
           label='VOFF', color='lightcoral', edgecolor='black')
    
    ax.set_ylabel('% Agents with significant GC')
    ax.set_title(f'{regime}: Significant Granger Causality\n(p < 0.05)')
    ax.set_xticks(x)
    ax.set_xticklabels(['E_env → γ', 'γ → E_env'])
    ax.legend()
    ax.grid(alpha=0.3, axis='y')
    
    # Anotar valores
    for i, (app_val, voff_val) in enumerate(zip(
        [sig_E_gamma_app, sig_gamma_E_app],
        [sig_E_gamma_voff, sig_gamma_E_voff]
    )):
        ax.text(i - width/2, app_val + 2, f'{app_val:.1f}%', ha='center', fontsize=9)
        ax.text(i + width/2, voff_val + 2, f'{voff_val:.1f}%', ha='center', fontsize=9)
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, f'granger_causality_{regime}.png'), 
                dpi=150, bbox_inches='tight')
    print(f"✓ Figura guardada: granger_causality_{regime}.png")
    plt.close()


def print_statistics(df_app, df_voff, regime):
    """
    Imprime estadísticas de Granger causality
    """
    print(f"\n{'='*70}")
    print(f"GRANGER CAUSALITY: {regime}")
    print(f"{'='*70}")
    
    print(f"\nE_env → γ (Environment drives agent):")
    app_sig = (df_app['gc_E_to_gamma_p'] < 0.05).sum()
    voff_sig = (df_voff['gc_E_to_gamma_p'] < 0.05).sum()
    print(f"  APP:  {app_sig}/{len(df_app)} agentes significativos ({app_sig/len(df_app)*100:.1f}%)")
    print(f"  VOFF: {voff_sig}/{len(df_voff)} agentes significativos ({voff_sig/len(df_voff)*100:.1f}%)")
    
    app_median = np.median(df_app['gc_E_to_gamma_p'])
    voff_median = np.median(df_voff['gc_E_to_gamma_p'])
    print(f"  Median p-value: APP={app_median:.4f}, VOFF={voff_median:.4f}")
    
    print(f"\nγ → E_env (Agent influences environment):")
    app_sig = (df_app['gc_gamma_to_E_p'] < 0.05).sum()
    voff_sig = (df_voff['gc_gamma_to_E_p'] < 0.05).sum()
    print(f"  APP:  {app_sig}/{len(df_app)} agentes significativos ({app_sig/len(df_app)*100:.1f}%)")
    print(f"  VOFF: {voff_sig}/{len(df_voff)} agentes significativos ({voff_sig/len(df_voff)*100:.1f}%)")
    
    app_median = np.median(df_app['gc_gamma_to_E_p'])
    voff_median = np.median(df_voff['gc_gamma_to_E_p'])
    print(f"  Median p-value: APP={app_median:.4f}, VOFF={voff_median:.4f}")
    
    # Interpretación
    print(f"\nINTERPRETACIÓN:")
    if (df_voff['gc_E_to_gamma_p'] < 0.05).mean() > 0.7:
        print(f"  ✓ VOFF es primariamente REACTIVO (E → γ fuerte)")
    if (df_app['gc_gamma_to_E_p'] < 0.05).mean() > 0.3:
        print(f"  ✓ APP muestra señales de influencia ACTIVA (γ → E presente)")


def main():
    parser = argparse.ArgumentParser(description='Análisis de Granger causality')
    parser.add_argument('--app_agents', required=True)
    parser.add_argument('--voff_agents', required=True)
    parser.add_argument('--app_ticks', required=True)
    parser.add_argument('--voff_ticks', required=True)
    parser.add_argument('--regime', required=True, choices=['RE', 'RH', 'RC'])
    parser.add_argument('--output_dir', default='granger_analysis')
    parser.add_argument('--max_lag', type=int, default=10)
    
    args = parser.parse_args()
    
    print(f"\n{'='*70}")
    print(f"GRANGER CAUSALITY ANALYSIS: {args.regime}")
    print(f"{'='*70}\n")
    
    # Analizar
    results_app = analyze_policy(args.app_agents, args.app_ticks, 'APP', args.max_lag)
    results_voff = analyze_policy(args.voff_agents, args.voff_ticks, 'VOFF', args.max_lag)
    
    if len(results_app) == 0 or len(results_voff) == 0:
        print("❌ No hay suficientes datos")
        return
    
    # DataFrames
    df_app = pd.DataFrame(results_app)
    df_voff = pd.DataFrame(results_voff)
    
    # Guardar
    os.makedirs(args.output_dir, exist_ok=True)
    df_app.to_csv(os.path.join(args.output_dir, f'granger_{args.regime}_APP.csv'), index=False)
    df_voff.to_csv(os.path.join(args.output_dir, f'granger_{args.regime}_VOFF.csv'), index=False)
    
    # Estadísticas
    print_statistics(df_app, df_voff, args.regime)
    
    # Visualizar
    plot_granger_results(df_app, df_voff, args.regime, args.output_dir)
    
    print(f"\n✅ Análisis completo")
    print(f"📁 Resultados en: {args.output_dir}/\n")


if __name__ == "__main__":
    main()
