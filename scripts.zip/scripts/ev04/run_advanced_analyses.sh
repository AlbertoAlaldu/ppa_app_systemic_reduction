#!/bin/bash
# ===============================================================
# ADVANCED ANALYSES LAUNCHER (EV-04) — Versión con resumen final
# ===============================================================

DATA_ROOT="/mnt/c/APP_MB_SIM/aim3_ev04_chat"
OUT_DIR="$DATA_ROOT/granger_analysis"
mkdir -p "$OUT_DIR"

# ---------------------------------------------------------------
# 1️⃣ REGIMEN RE (series largas)
# ---------------------------------------------------------------
echo "=== REGIMEN RE ==="
python analyze_granger_causality.py \
  --base_dir "$DATA_ROOT/RE/APP" \
  --out_csv "$OUT_DIR/granger_RE_APP.csv"

python analyze_granger_causality.py \
  --base_dir "$DATA_ROOT/RE/VOFF" \
  --out_csv "$OUT_DIR/granger_RE_VOFF.csv"

# ---------------------------------------------------------------
# 2️⃣ REGIMEN RH (series cortas)
# ---------------------------------------------------------------
echo "=== REGIMEN RH ==="
python analyze_granger_fix.py \
  --base_dir "$DATA_ROOT/RH/APP" \
  --out_csv "$OUT_DIR/granger_RH_APP.csv"

python analyze_granger_fix.py \
  --base_dir "$DATA_ROOT/RH/VOFF" \
  --out_csv "$OUT_DIR/granger_RH_VOFF.csv"

# ---------------------------------------------------------------
# 3️⃣ REGIMEN RC (series cortas)
# ---------------------------------------------------------------
echo "=== REGIMEN RC ==="
python analyze_granger_fix.py \
  --base_dir "$DATA_ROOT/RC/APP" \
  --out_csv "$OUT_DIR/granger_RC_APP.csv"

python analyze_granger_fix.py \
  --base_dir "$DATA_ROOT/RC/VOFF" \
  --out_csv "$OUT_DIR/granger_RC_VOFF.csv"

# ---------------------------------------------------------------
# 4️⃣ POST-ANÁLISIS OPCIONAL
# ---------------------------------------------------------------
echo "Analizando atractores y métricas temporales..."
python analyze_phase_space.py
python create_comparison_figure.py

# ---------------------------------------------------------------
# 5️⃣ RESUMEN FINAL AUTOMÁTICO
# ---------------------------------------------------------------
echo ""
echo "==============================================================="
echo "[RESUMEN FINAL] - Agentes analizados por régimen/política"
echo "==============================================================="

for f in "$OUT_DIR"/granger_*.csv; do
  if [[ -f \"$f\" ]]; then
    name=$(basename \"$f\" .csv)
    count=$(awk -F',' 'NR>1 {c++} END {print c+0}' \"$f\")
    echo \"$name: $count agentes\"
  fi
done

echo "==============================================================="
echo "✅ Todos los análisis completados correctamente."
echo "Archivos de salida: $OUT_DIR"
echo "==============================================================="
