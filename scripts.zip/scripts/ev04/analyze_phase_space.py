#!/usr/bin/env python3
"""
Análisis de Phase Space Attractors

Visualiza trayectorias γ vs E_env en espacio de fase para detectar:
- Attractors (puntos fijos, ciclos límite)
- Hysteresis loops
- Diferencias entre APP y VOFF

Uso:
    python analyze_phase_space.py \
        --app_agents path/to/APP/agents \
        --voff_agents path/to/VOFF/agents \
        --app_ticks path/to/APP/tick_data \
        --voff_ticks path/to/VOFF/tick_data \
        --regime RC \
        --output_dir phase_space_results
"""

import argparse
import glob
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.patches import Ellipse
from scipy.stats import gaussian_kde
import warnings
warnings.filterwarnings('ignore')

def load_agent_trajectory(agent_path, tick_path, min_length=30):
    """
    Carga trayectoria completa de un agente
    """
    agent = pd.read_csv(agent_path)
    tick = pd.read_csv(tick_path)
    
    df = pd.merge(agent, tick[['tick', 'E_env']], on='tick', how='inner')
    df = df[df['alive'] == 1].copy()
    
    if len(df) < min_length:
        return None
    
    return df


def compute_attractor_metrics(trajectory):
    """
    Calcula métricas del attractor
    """
    gamma = trajectory['gamma'].values
    E_env = trajectory['E_env'].values
    
    # Centro del attractor
    center = (np.mean(E_env), np.mean(gamma))
    
    # Área ocupada (convex hull aproximado)
    area = np.std(E_env) * np.std(gamma) * np.pi
    
    # Eccentricity (qué tan "estirado" es)
    cov = np.cov(E_env, gamma)
    eigenvalues = np.linalg.eigvals(cov)
    eccentricity = np.sqrt(1 - min(eigenvalues) / max(eigenvalues)) if max(eigenvalues) > 0 else 0
    
    # Path length (longitud de trayectoria)
    distances = np.sqrt(np.diff(E_env)**2 + np.diff(gamma)**2)
    path_length = np.sum(distances)
    
    # Tortuosity (cuánto serpentea)
    euclidean_distance = np.sqrt((E_env[-1] - E_env[0])**2 + (gamma[-1] - gamma[0])**2)
    tortuosity = path_length / (euclidean_distance + 1e-10)
    
    return {
        'center_E': center[0],
        'center_gamma': center[1],
        'area': area,
        'eccentricity': eccentricity,
        'path_length': path_length,
        'tortuosity': tortuosity,
        'n_points': len(gamma)
    }


def plot_individual_trajectories(trajectories_app, trajectories_voff, regime, output_dir, n_samples=5):
    """
    Plotea trayectorias individuales de ejemplo
    """
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    
    # APP
    ax = axes[0]
    for i, traj in enumerate(trajectories_app[:n_samples]):
        if traj is not None:
            gamma = traj['gamma'].values
            E_env = traj['E_env'].values
            
            # Gradiente de color por tiempo
            points = np.array([E_env, gamma]).T.reshape(-1, 1, 2)
            segments = np.concatenate([points[:-1], points[1:]], axis=1)
            
            colors = np.linspace(0, 1, len(E_env))
            
            ax.plot(E_env, gamma, alpha=0.6, linewidth=1.5, label=f'Agent {i+1}')
            ax.scatter(E_env[0], gamma[0], s=100, marker='o', edgecolor='black', 
                      linewidths=2, zorder=10, label='Start' if i == 0 else '')
            ax.scatter(E_env[-1], gamma[-1], s=100, marker='s', edgecolor='black',
                      linewidths=2, zorder=10, label='End' if i == 0 else '')
    
    ax.set_xlabel('E_env', fontsize=12)
    ax.set_ylabel('γ', fontsize=12)
    ax.set_title(f'{regime} - APP Trajectories', fontsize=14, fontweight='bold')
    ax.grid(alpha=0.3)
    ax.legend(fontsize=8)
    
    # VOFF
    ax = axes[1]
    for i, traj in enumerate(trajectories_voff[:n_samples]):
        if traj is not None:
            gamma = traj['gamma'].values
            E_env = traj['E_env'].values
            
            ax.plot(E_env, gamma, alpha=0.6, linewidth=1.5, label=f'Agent {i+1}')
            ax.scatter(E_env[0], gamma[0], s=100, marker='o', edgecolor='black',
                      linewidths=2, zorder=10, label='Start' if i == 0 else '')
            ax.scatter(E_env[-1], gamma[-1], s=100, marker='s', edgecolor='black',
                      linewidths=2, zorder=10, label='End' if i == 0 else '')
    
    ax.set_xlabel('E_env', fontsize=12)
    ax.set_ylabel('γ', fontsize=12)
    ax.set_title(f'{regime} - VOFF Trajectories', fontsize=14, fontweight='bold')
    ax.grid(alpha=0.3)
    ax.legend(fontsize=8)
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, f'trajectories_individual_{regime}.png'),
                dpi=150, bbox_inches='tight')
    print(f"✓ Figura guardada: trajectories_individual_{regime}.png")
    plt.close()


def plot_density_map(trajectories_app, trajectories_voff, regime, output_dir):
    """
    Mapa de densidad del espacio de fase
    """
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    
    # Recopilar todos los puntos
    points_app = []
    for traj in trajectories_app:
        if traj is not None:
            points_app.extend(list(zip(traj['E_env'].values, traj['gamma'].values)))
    
    points_voff = []
    for traj in trajectories_voff:
        if traj is not None:
            points_voff.extend(list(zip(traj['E_env'].values, traj['gamma'].values)))
    
    points_app = np.array(points_app)
    points_voff = np.array(points_voff)
    
    # APP density
    ax = axes[0]
    if len(points_app) > 100:
        ax.hexbin(points_app[:, 0], points_app[:, 1], gridsize=30, cmap='Blues', mincnt=1)
        ax.set_xlabel('E_env', fontsize=12)
        ax.set_ylabel('γ', fontsize=12)
        ax.set_title(f'{regime} - APP Density Map', fontsize=14, fontweight='bold')
        
        # Añadir centro de masa
        center_E = np.mean(points_app[:, 0])
        center_gamma = np.mean(points_app[:, 1])
        ax.scatter(center_E, center_gamma, s=200, marker='x', color='red', 
                  linewidths=3, label='Center of mass')
        ax.legend()
    
    # VOFF density
    ax = axes[1]
    if len(points_voff) > 100:
        ax.hexbin(points_voff[:, 0], points_voff[:, 1], gridsize=30, cmap='Reds', mincnt=1)
        ax.set_xlabel('E_env', fontsize=12)
        ax.set_ylabel('γ', fontsize=12)
        ax.set_title(f'{regime} - VOFF Density Map', fontsize=14, fontweight='bold')
        
        center_E = np.mean(points_voff[:, 0])
        center_gamma = np.mean(points_voff[:, 1])
        ax.scatter(center_E, center_gamma, s=200, marker='x', color='blue',
                  linewidths=3, label='Center of mass')
        ax.legend()
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, f'density_map_{regime}.png'),
                dpi=150, bbox_inches='tight')
    print(f"✓ Figura guardada: density_map_{regime}.png")
    plt.close()


def plot_attractor_comparison(metrics_app, metrics_voff, regime, output_dir):
    """
    Compara métricas de attractors
    """
    df_app = pd.DataFrame(metrics_app)
    df_voff = pd.DataFrame(metrics_voff)
    
    fig, axes = plt.subplots(2, 2, figsize=(12, 10))
    
    metrics_to_plot = [
        ('area', 'Attractor Area', ''),
        ('eccentricity', 'Eccentricity', ''),
        ('path_length', 'Path Length', ''),
        ('tortuosity', 'Tortuosity', '')
    ]
    
    for idx, (metric, title, unit) in enumerate(metrics_to_plot):
        ax = axes[idx // 2, idx % 2]
        
        data_app = df_app[metric].values
        data_voff = df_voff[metric].values
        
        bp = ax.boxplot([data_app, data_voff], positions=[1, 2], widths=0.6,
                        patch_artist=True, showfliers=True)
        
        bp['boxes'][0].set_facecolor('lightblue')
        bp['boxes'][1].set_facecolor('lightcoral')
        
        ax.set_xticks([1, 2])
        ax.set_xticklabels(['APP', 'VOFF'])
        ax.set_ylabel(f'{title}' + (f' ({unit})' if unit else ''))
        ax.grid(alpha=0.3, axis='y')
        
        # Medianas
        med_app = np.median(data_app)
        med_voff = np.median(data_voff)
        ax.text(1, med_app, f'{med_app:.2f}', ha='center', va='bottom', fontsize=9)
        ax.text(2, med_voff, f'{med_voff:.2f}', ha='center', va='bottom', fontsize=9)
    
    plt.suptitle(f'{regime}: Phase Space Attractor Metrics', fontsize=14, fontweight='bold')
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, f'attractor_metrics_{regime}.png'),
                dpi=150, bbox_inches='tight')
    print(f"✓ Figura guardada: attractor_metrics_{regime}.png")
    plt.close()


def analyze_policy(agents_dir, ticks_dir, policy_name):
    """
    Analiza todos los agentes de una política
    """
    agent_files = sorted(glob.glob(os.path.join(agents_dir, "*.csv")))
    
    if len(agent_files) == 0:
        print(f"⚠️  No se encontraron archivos en {agents_dir}")
        return [], []
    
    tick_pattern = os.path.join(ticks_dir, "*.csv")
    tick_files = glob.glob(tick_pattern)
    
    if len(tick_files) == 0:
        print(f"⚠️  No se encontró tick_data")
        return [], []
    
    tick_path = tick_files[0]
    
    print(f"📊 Analizando {len(agent_files)} agentes de {policy_name}...")
    
    trajectories = []
    metrics = []
    
    for agent_path in agent_files:
        traj = load_agent_trajectory(agent_path, tick_path)
        if traj is not None:
            trajectories.append(traj)
            metric = compute_attractor_metrics(traj)
            metric['policy'] = policy_name
            metrics.append(metric)
    
    print(f"   ✓ {len(trajectories)} trayectorias analizadas")
    
    return trajectories, metrics


def main():
    parser = argparse.ArgumentParser(description='Análisis de phase space attractors')
    parser.add_argument('--app_agents', required=True)
    parser.add_argument('--voff_agents', required=True)
    parser.add_argument('--app_ticks', required=True)
    parser.add_argument('--voff_ticks', required=True)
    parser.add_argument('--regime', required=True, choices=['RE', 'RH', 'RC'])
    parser.add_argument('--output_dir', default='phase_space_analysis')
    parser.add_argument('--n_samples', type=int, default=5, help='Número de trayectorias de ejemplo a plotear')
    
    args = parser.parse_args()
    
    print(f"\n{'='*70}")
    print(f"PHASE SPACE ATTRACTOR ANALYSIS: {args.regime}")
    print(f"{'='*70}\n")
    
    # Analizar
    traj_app, metrics_app = analyze_policy(args.app_agents, args.app_ticks, 'APP')
    traj_voff, metrics_voff = analyze_policy(args.voff_agents, args.voff_ticks, 'VOFF')
    
    if len(traj_app) == 0 or len(traj_voff) == 0:
        print("❌ No hay suficientes datos")
        return
    
    # Crear output dir
    os.makedirs(args.output_dir, exist_ok=True)
    
    # Guardar métricas
    pd.DataFrame(metrics_app).to_csv(
        os.path.join(args.output_dir, f'attractor_metrics_{args.regime}_APP.csv'),
        index=False
    )
    pd.DataFrame(metrics_voff).to_csv(
        os.path.join(args.output_dir, f'attractor_metrics_{args.regime}_VOFF.csv'),
        index=False
    )
    
    # Visualizaciones
    print("\nGenerando visualizaciones...")
    plot_individual_trajectories(traj_app, traj_voff, args.regime, args.output_dir, args.n_samples)
    plot_density_map(traj_app, traj_voff, args.regime, args.output_dir)
    plot_attractor_comparison(metrics_app, metrics_voff, args.regime, args.output_dir)
    
    print(f"\n✅ Análisis completo")
    print(f"📁 Resultados en: {args.output_dir}/\n")


if __name__ == "__main__":
    main()
