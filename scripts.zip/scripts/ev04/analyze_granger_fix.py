import os
import pandas as pd
import numpy as np
from statsmodels.tsa.stattools import grangercausalitytests
import matplotlib.pyplot as plt

# ===============================================================
# CONFIGURACIÓN AJUSTADA PARA RH Y RC (series cortas)
# ===============================================================
MIN_POINTS = 20          # mínimo de puntos vivos requeridos (antes era 100)
MAX_LAG = 3              # lag máximo del test (antes era 8 o 10)
P_THRESHOLD = 0.05       # umbral de significancia

# ===============================================================

def analyze_pair(series_env, series_gamma):
    """Ejecuta el test de Granger para dos series (E_env → γ y γ → E_env)."""
    try:
        data = np.column_stack([series_env, series_gamma])
        result = grangercausalitytests(data, maxlag=MAX_LAG, verbose=False)
        p_vals_E_to_gamma = [result[i+1][0]['ssr_ftest'][1] for i in range(MAX_LAG)]
        p_vals_gamma_to_E = [result[i+1][0]['ssr_ftest'][1] for i in range(MAX_LAG)]
        return min(p_vals_E_to_gamma), min(p_vals_gamma_to_E)
    except Exception:
        return np.nan, np.nan

def run_analysis(base_dir, out_csv):
    agents_dir = os.path.join(base_dir, 'agents')
    tick_dir = os.path.join(base_dir, 'tick_data')
    results = []

    if not os.path.exists(agents_dir) or not os.path.exists(tick_dir):
        print(f"⚠️ Directorios no encontrados en {base_dir}")
        return

    for agent_file in os.listdir(agents_dir):
        agent_path = os.path.join(agents_dir, agent_file)
        tick_path = os.path.join(tick_dir, agent_file)
        if not os.path.exists(tick_path):
            continue

        df_agent = pd.read_csv(agent_path)
        df_tick = pd.read_csv(tick_path)
        df = pd.merge(df_agent, df_tick, on='tick', suffixes=('_agent', '_env'))
        df_alive = df[df['alive'] == 1]

        if len(df_alive) < MIN_POINTS:
            continue  # salta agentes con muy poca ventana viva

        E_env = df_alive['E_env'].values
        gamma = df_alive['gamma'].values

        p_E_to_gamma, p_gamma_to_E = analyze_pair(E_env, gamma)

        results.append({
            'agent_file': agent_file,
            'n_ticks': len(df_alive),
            'gc_E_to_gamma_p': p_E_to_gamma,
            'gc_gamma_to_E_p': p_gamma_to_E
        })

    if not results:
        print(f"❌ No hay suficientes datos en {base_dir}")
        return

    df_res = pd.DataFrame(results)
    df_res.to_csv(out_csv, index=False)
    print(f"✅ {len(df_res)} agentes analizados y guardados en {out_csv}")

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='Granger causality for EV04 regimes')
    parser.add_argument('--base_dir', type=str, required=True, help='Ruta base (p. ej. RH/APP)')
    parser.add_argument('--out_csv', type=str, required=True, help='Archivo de salida CSV')
    args = parser.parse_args()

    run_analysis(args.base_dir, args.out_csv)
