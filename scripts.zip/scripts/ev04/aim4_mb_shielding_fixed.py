#!/usr/bin/env python3
import os
import glob
import argparse
import numpy as np
import pandas as pd
import pingouin as pg

def safe_partial_corr(df):
    """Intenta corr parcial; si no se puede, intenta corr simple; si no, devuelve 0.0."""
    # variables constantes → no se puede
    if df["gamma"].nunique() < 2 or df["E_env"].nunique() < 2:
        return 0.0, 1.0

    # primero parcial
    try:
        pc = pg.partial_corr(data=df, x="gamma", y="E_env", covar="A", method="pearson")
        r = float(pc.loc[0, "r"])
        p = float(pc.loc[0, "p-val"])
        # si salió bien, ya
        if not np.isnan(r):
            return r, p
    except Exception:
        pass

    # si la parcial falló, intenta corr simple
    try:
        c = pg.corr(df["gamma"], df["E_env"], method="pearson")
        r = float(c.loc[0, "r"])
        p = float(c.loc[0, "p-val"])
        if not np.isnan(r):
            return r, p
    except Exception:
        pass

    # último recurso
    return 0.0, 1.0


def compute_rho_one_agent(agent_path, tick_dir, window_length=80, min_alive=10):
    base = os.path.basename(agent_path)
    parts = base.split("_")
    if len(parts) < 5:
        return None

    regime = parts[0]
    policy = parts[1]
    arch   = parts[2]
    seed   = parts[3].replace("seed", "")

    tick_path = os.path.join(tick_dir, f"{regime}_{policy}_{arch}_seed{seed}.csv")
    if not os.path.exists(tick_path):
        return None

    df_agent = pd.read_csv(agent_path)
    df_tick  = pd.read_csv(tick_path)[["tick", "E_env", "G_env"]]

    df = pd.merge(df_agent, df_tick, on="tick", how="inner")
    df["A"] = df["u"] * df["G_env"]

    # nos quedamos con vivos
    df = df[df["alive"] == 1].copy()
    if len(df) < min_alive:
        # muy pocos → devolvemos 0.0
        return {
            "regime": regime,
            "policy": policy,
            "seed": int(seed),
            "rho_value": 0.0,
            "p_value": 1.0,
            "n": len(df)
        }

    df = df.tail(window_length)

    r, p = safe_partial_corr(df)

    return {
        "regime": regime,
        "policy": policy,
        "seed": int(seed),
        "rho_value": r,
        "p_value": p,
        "n": len(df)
    }


def analyze_directory(agent_dir, tick_dir, output_csv, window_length=80, min_alive=10):
    rows = []
    agent_files = sorted(glob.glob(os.path.join(agent_dir, "*.csv")))
    print(f"📁 Analizando {agent_dir}")
    print(f"   → {len(agent_files)} archivos de agentes")

    for agent_path in agent_files:
        res = compute_rho_one_agent(agent_path, tick_dir, window_length, min_alive)
        if res is not None:
            rows.append(res)

    df = pd.DataFrame(rows)
    df.to_csv(output_csv, index=False)
    print(f"✅ Guardado: {output_csv}")

    if not df.empty:
        # medianas por régimen/policy
        print(df.groupby(["regime", "policy"])["rho_value"].median())


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input_dir", required=True)
    parser.add_argument("--tick_dir", required=True)
    parser.add_argument("--output_csv", required=True)
    parser.add_argument("--window_length", type=int, default=80)
    parser.add_argument("--min_alive", type=int, default=10)
    args = parser.parse_args()

    analyze_directory(
        args.input_dir,
        args.tick_dir,
        args.output_csv,
        args.window_length,
        args.min_alive,
    )

