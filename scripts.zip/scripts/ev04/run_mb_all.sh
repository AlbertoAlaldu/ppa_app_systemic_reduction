#!/bin/bash

WINDOW=80
ALIVE_FRAC=0.6

echo "🧩 Analizando blindaje metabólico..."
echo "----------------------------------"

# 1) RE APP-Fixed
echo "📁 Analizando RE APP-Fixed ..."
python aim4_mb_shielding_fixed.py \
  --input_dir outputs_EV-04_RE_APP-Fixed/agents \
  --tick_dir  outputs_EV-04_RE_APP-Fixed/tick_data \
  --output_csv data_aim4_mb_shielding_EV-04_RE_APP-Fixed.csv \
  --window_length $WINDOW

# 2) RE VOFF
echo "📁 Analizando RE VOFF ..."
python aim4_mb_shielding_fixed.py \
  --input_dir outputs_EV-04_RE_VOFF/agents \
  --tick_dir  outputs_EV-04_RE_VOFF/tick_data \
  --output_csv data_aim4_mb_shielding_EV-04_RE_VOFF.csv \
  --window_length $WINDOW

# 3) RH APP-Fixed
echo "📁 Analizando RH APP-Fixed ..."
python aim4_mb_shielding_fixed.py \
  --input_dir outputs_EV-04_RH_APP-Fixed/agents \
  --tick_dir  outputs_EV-04_RH_APP-Fixed/tick_data \
  --output_csv data_aim4_mb_shielding_EV-04_RH_APP-Fixed.csv \
  --window_length $WINDOW

# 4) RH VOFF
echo "📁 Analizando RH VOFF ..."
python aim4_mb_shielding_fixed.py \
  --input_dir outputs_EV-04_RH_VOFF/agents \
  --tick_dir  outputs_EV-04_RH_VOFF/tick_data \
  --output_csv data_aim4_mb_shielding_EV-04_RH_VOFF.csv \
  --window_length $WINDOW

# 5) RC APP-Fixed
echo "📁 Analizando RC APP-Fixed ..."
python aim4_mb_shielding_fixed.py \
  --input_dir outputs_EV-04_RC_APP-Fixed/agents \
  --tick_dir  outputs_EV-04_RC_APP-Fixed/tick_data \
  --output_csv data_aim4_mb_shielding_EV-04_RC_APP-Fixed.csv \
  --window_length $WINDOW

# 6) RC VOFF
echo "📁 Analizando RC VOFF ..."
python aim4_mb_shielding_fixed.py \
  --input_dir outputs_EV-04_RC_VOFF/agents \
  --tick_dir  outputs_EV-04_RC_VOFF/tick_data \
  --output_csv data_aim4_mb_shielding_EV-04_RC_VOFF.csv \
  --window_length $WINDOW

echo "✅ Listo."
