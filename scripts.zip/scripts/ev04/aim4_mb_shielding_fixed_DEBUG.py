#!/usr/bin/env python3
"""
AIM-4 — Markov-Blanket Shielding (Debug Version)
Depuración transparente del cálculo de correlación parcial ρ̃ = corr(γ, E_env | A)

© Paradox Systems R&D — Ing. Alberto Duarte / Ing. ChatGPT
"""

import os
import glob
import argparse
import pandas as pd
import numpy as np

# ==========================
#  Función segura y explícita
# ==========================
def safe_partial_corr(df):
    try:
        import pingouin as pg
        X = df[["gamma", "E_env", "A"]].dropna()

        if len(X) < 5:
            print(f"⚠️  Demasiados pocos datos ({len(X)}), devolviendo 0.0")
            return 0.0, 1.0

        r = pg.partial_corr(data=X, x="gamma", y="E_env", covar="A", method="pearson")
        r_val = float(r["r"].iloc[0])
        p_val = float(r["p-val"].iloc[0])

        if np.isnan(r_val):
            print("⚠️  Correlación NaN → devolviendo 0.0")
            return 0.0, 1.0

        return r_val, p_val

    except Exception as e:
        print(f"❌ Error en safe_partial_corr: {e}")
        return 0.0, 1.0


# ==========================
#  Cálculo por agente
# ==========================
def compute_rho_one_agent(agent_path, tick_dir, window_length=80, min_alive=10):
    base = os.path.basename(agent_path)
    parts = base.split("_")
    regime, policy, arch = parts[0], parts[1], parts[2]

    try:
        df_agent = pd.read_csv(agent_path)
        seed = df_agent["seed"].iloc[0] if "seed" in df_agent else 0
    except Exception as e:
        print(f"❌ Error leyendo {agent_path}: {e}")
        return None

    tick_file = os.path.join(tick_dir, f"{regime}_{policy}_{arch}_seed{seed}.csv")
    if not os.path.exists(tick_file):
        print(f"⚠️  Tick file no encontrado para {base}")
        return None

    try:
        df_tick = pd.read_csv(tick_file)
        df = pd.merge(df_agent, df_tick[["tick", "E_env", "G_env"]], on="tick", how="inner")
        df = df[df["alive"] == 1].copy()
        df["A"] = df["u"] * df["G_env"]
    except Exception as e:
        print(f"❌ Error combinando datos para {base}: {e}")
        return None

    n_alive = len(df)
    if n_alive < min_alive:
        print(f"⚠️  {base}: solo {n_alive} ticks vivos — skipping")
        return None

    # --- Cambio importante: usar TODA la vida viva, no tail(80)
    df_window = df.tail(window_length) if len(df) > window_length else df

    r, p = safe_partial_corr(df_window)
    return {
        "seed": seed,
        "regime": regime,
        "policy": policy,
        "architecture": arch,
        "agent": base,
        "rho_value": r,
        "p_value": p,
        "n_alive": n_alive,
        "n_window": len(df_window)
    }


# ==========================
#  Main
# ==========================
def main():
    parser = argparse.ArgumentParser(description="Compute Markov-blanket shielding with debug info")
    parser.add_argument("--input_dir", required=True)
    parser.add_argument("--tick_dir", required=True)
    parser.add_argument("--output_csv", required=True)
    parser.add_argument("--window_length", type=int, default=80)
    args = parser.parse_args()

    files = sorted(glob.glob(os.path.join(args.input_dir, "*.csv")))
    print(f"📁 Analizando {args.input_dir}")
    print(f"   → {len(files)} archivos de agentes")

    results = []
    for path in files:
        res = compute_rho_one_agent(path, args.tick_dir, args.window_length)
        if res:
            print(f"✅ {res['agent']} → ρ̃={res['rho_value']:.3f}, p={res['p_value']:.3f}, vivos={res['n_alive']}")
            results.append(res)

    if not results:
        print("❌ No se generaron resultados válidos")
        return

    df = pd.DataFrame(results)
    summary = df.groupby(["regime", "policy"])["rho_value"].mean()
    print("Resumen final:\n", summary)
    df.to_csv(args.output_csv, index=False)
    print(f"✅ Guardado: {args.output_csv}")


if __name__ == "__main__":
    main()
