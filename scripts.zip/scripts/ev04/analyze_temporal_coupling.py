#!/usr/bin/env python3
"""
Análisis de acoplamiento temporal entre agente y ambiente
Detecta fenómenos emergentes de sincronización en régimen RC

Uso:
    python analyze_temporal_coupling.py \
        --app_agents path/to/APP/agents \
        --voff_agents path/to/VOFF/agents \
        --app_ticks path/to/APP/tick_data \
        --voff_ticks path/to/VOFF/tick_data \
        --output_dir results_temporal
"""

import argparse
import glob
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import signal, stats
from scipy.stats import mannwhitneyu
from sklearn.feature_selection import mutual_info_regression
import warnings
warnings.filterwarnings('ignore')

# ============================================================================
# FUNCIONES DE ANÁLISIS
# ============================================================================

def compute_cross_correlation(x, y, max_lag=20):
    """
    Calcula correlación cruzada entre dos series temporales
    
    Returns:
        lags: array de lags probados
        corrs: correlaciones en cada lag
        optimal_lag: lag con máxima correlación
        max_corr: valor máximo de correlación
    """
    # Normalizar series
    x = (x - np.mean(x)) / (np.std(x) + 1e-10)
    y = (y - np.mean(y)) / (np.std(y) + 1e-10)
    
    lags = np.arange(-max_lag, max_lag + 1)
    corrs = []
    
    for lag in lags:
        if lag < 0:
            corr = np.corrcoef(x[:lag], y[-lag:])[0, 1]
        elif lag > 0:
            corr = np.corrcoef(x[lag:], y[:-lag])[0, 1]
        else:
            corr = np.corrcoef(x, y)[0, 1]
        
        corrs.append(corr if not np.isnan(corr) else 0)
    
    corrs = np.array(corrs)
    optimal_lag = lags[np.argmax(np.abs(corrs))]
    max_corr = corrs[np.argmax(np.abs(corrs))]
    
    return lags, corrs, optimal_lag, max_corr


def compute_mutual_information(x, y, max_lag=20, n_bins=10):
    """
    Calcula información mutua para diferentes lags
    Captura dependencias no-lineales
    
    Returns:
        lags: array de lags
        mi_values: información mutua en cada lag
        optimal_lag: lag con máxima MI
        max_mi: valor máximo de MI
    """
    lags = np.arange(-max_lag, max_lag + 1)
    mi_values = []
    
    for lag in lags:
        if lag < 0:
            x_shifted = x[:lag].reshape(-1, 1)
            y_shifted = y[-lag:]
        elif lag > 0:
            x_shifted = x[lag:].reshape(-1, 1)
            y_shifted = y[:-lag]
        else:
            x_shifted = x.reshape(-1, 1)
            y_shifted = y
        
        if len(x_shifted) < 10:
            mi_values.append(0)
            continue
        
        # Usar mutual_info_regression de sklearn
        mi = mutual_info_regression(x_shifted, y_shifted, 
                                    n_neighbors=min(3, len(x_shifted)-1),
                                    random_state=42)[0]
        mi_values.append(mi)
    
    mi_values = np.array(mi_values)
    optimal_lag = lags[np.argmax(mi_values)]
    max_mi = np.max(mi_values)
    
    return lags, mi_values, optimal_lag, max_mi


def compute_transfer_entropy(source, target, k=1):
    """
    Aproximación simplificada de Transfer Entropy
    TE(X→Y) mide cuánta información provee X sobre el futuro de Y
    más allá de la historia de Y
    
    TE(X→Y) ≈ MI(Y_t+1, X_t | Y_t) ≈ MI(Y_t+1, X_t) - MI(Y_t+1, Y_t)
    """
    if len(source) < 10 or len(target) < 10:
        return 0
    
    # Preparar series
    target_future = target[k:]
    source_past = source[:-k]
    target_past = target[:-k]
    
    if len(target_future) < 5:
        return 0
    
    # MI(Y_t+1, X_t)
    mi_source = mutual_info_regression(
        source_past.reshape(-1, 1), 
        target_future,
        n_neighbors=min(3, len(target_future)-1),
        random_state=42
    )[0]
    
    # MI(Y_t+1, Y_t) 
    mi_history = mutual_info_regression(
        target_past.reshape(-1, 1),
        target_future,
        n_neighbors=min(3, len(target_future)-1),
        random_state=42
    )[0]
    
    # TE ≈ diferencia
    te = max(0, mi_source - mi_history)
    
    return te


def compute_spectral_coherence(x, y, fs=1.0):
    """
    Calcula coherencia espectral entre dos señales
    Mide correlación como función de frecuencia
    
    Returns:
        freqs: frecuencias
        coherence: coherencia en cada frecuencia
        dominant_freq: frecuencia con máxima coherencia
        max_coherence: coherencia máxima
    """
    if len(x) < 20 or len(y) < 20:
        return np.array([]), np.array([]), 0, 0
    
    # Calcular coherencia
    freqs, coherence = signal.coherence(x, y, fs=fs, nperseg=min(len(x)//4, 32))
    
    # Ignorar frecuencia 0 (DC component)
    if len(freqs) > 1:
        dominant_freq = freqs[1:][np.argmax(coherence[1:])]
        max_coherence = np.max(coherence[1:])
    else:
        dominant_freq = 0
        max_coherence = 0
    
    return freqs, coherence, dominant_freq, max_coherence


def analyze_single_agent(agent_path, tick_path, max_lag=20):
    """
    Analiza un agente individual
    
    Returns:
        dict con métricas de acoplamiento temporal
    """
    # Cargar datos
    agent = pd.read_csv(agent_path)
    
    # Extraer seed y régimen del nombre del archivo
    basename = os.path.basename(tick_path)
    
    # Cargar tick_data correspondiente
    tick = pd.read_csv(tick_path)
    
    # Merge por tick
    df = pd.merge(agent, tick[['tick', 'E_env', 'G_env']], on='tick', how='inner')
    
    # Solo agentes vivos
    df = df[df['alive'] == 1].copy()
    
    if len(df) < 20:
        return None
    
    # Extraer series temporales
    gamma = df['gamma'].values
    E_env = df['E_env'].values
    u = df['u'].values
    
    # 1. Cross-correlation
    lags_cc, corrs_cc, opt_lag_cc, max_corr_cc = compute_cross_correlation(
        E_env, gamma, max_lag=max_lag
    )
    
    # 2. Mutual information
    lags_mi, mi_vals, opt_lag_mi, max_mi = compute_mutual_information(
        E_env, gamma, max_lag=max_lag
    )
    
    # 3. Transfer entropy
    te_E_to_gamma = compute_transfer_entropy(E_env, gamma, k=1)
    te_gamma_to_E = compute_transfer_entropy(gamma, E_env, k=1)
    
    # 4. Spectral coherence
    freqs, coherence, dom_freq, max_coh = compute_spectral_coherence(gamma, E_env)
    
    # 5. Variabilidad (control de amplitud)
    var_gamma = np.var(gamma)
    var_E = np.var(E_env)
    amplitude_ratio = np.sqrt(var_gamma / (var_E + 1e-10))
    
    return {
        'n_ticks': len(df),
        'opt_lag_cc': opt_lag_cc,
        'max_corr_cc': max_corr_cc,
        'opt_lag_mi': opt_lag_mi,
        'max_mi': max_mi,
        'te_E_to_gamma': te_E_to_gamma,
        'te_gamma_to_E': te_gamma_to_E,
        'dominant_freq': dom_freq,
        'max_coherence': max_coh,
        'var_gamma': var_gamma,
        'var_E_env': var_E,
        'amplitude_ratio': amplitude_ratio,
        'gamma_mean': np.mean(gamma),
        'gamma_std': np.std(gamma),
        'E_mean': np.mean(E_env),
        'E_std': np.std(E_env)
    }


# ============================================================================
# ANÁLISIS POR POLÍTICA
# ============================================================================

def analyze_policy(agents_dir, ticks_dir, policy_name, max_lag=20):
    """
    Analiza todos los agentes de una política
    """
    agent_files = sorted(glob.glob(os.path.join(agents_dir, "*.csv")))
    
    # Inferir régimen y seed del primer archivo
    if len(agent_files) == 0:
        print(f"⚠️  No se encontraron archivos en {agents_dir}")
        return []
    
    # Extraer info del nombre
    basename = os.path.basename(agent_files[0])
    parts = basename.replace('.csv', '').split('_')
    regime = parts[0] if len(parts) > 0 else 'UNKNOWN'
    
    # Buscar archivo de tick_data correspondiente
    tick_pattern = os.path.join(ticks_dir, f"{regime}*.csv")
    tick_files = glob.glob(tick_pattern)
    
    if len(tick_files) == 0:
        print(f"⚠️  No se encontró tick_data para {regime}")
        return []
    
    tick_path = tick_files[0]
    
    print(f"📊 Analizando {len(agent_files)} agentes de {policy_name}...")
    
    results = []
    for agent_path in agent_files:
        res = analyze_single_agent(agent_path, tick_path, max_lag=max_lag)
        if res is not None:
            res['policy'] = policy_name
            res['agent_file'] = os.path.basename(agent_path)
            results.append(res)
    
    print(f"   ✓ {len(results)} agentes analizados")
    
    return results


# ============================================================================
# VISUALIZACIÓN
# ============================================================================

def plot_results(df_app, df_voff, output_dir):
    """
    Genera visualizaciones comparativas
    """
    os.makedirs(output_dir, exist_ok=True)
    
    # Configuración de estilo
    sns.set_style("whitegrid")
    plt.rcParams['figure.dpi'] = 150
    
    # ========================================================================
    # Figura 1: Comparación de métricas principales
    # ========================================================================
    
    fig, axes = plt.subplots(2, 3, figsize=(15, 10))
    
    metrics = [
        ('opt_lag_cc', 'Optimal Lag\n(Cross-Correlation)', 'ticks'),
        ('max_corr_cc', 'Max Correlation\n(γ, E_env)', ''),
        ('max_mi', 'Max Mutual Info\n(γ, E_env)', 'bits'),
        ('te_E_to_gamma', 'Transfer Entropy\n(E → γ)', 'bits'),
        ('te_gamma_to_E', 'Transfer Entropy\n(γ → E)', 'bits'),
        ('max_coherence', 'Max Spectral\nCoherence', '')
    ]
    
    for idx, (metric, title, unit) in enumerate(metrics):
        ax = axes[idx // 3, idx % 3]
        
        data_app = df_app[metric].values
        data_voff = df_voff[metric].values
        
        # Boxplot
        bp = ax.boxplot([data_app, data_voff], 
                        positions=[1, 2],
                        widths=0.6,
                        patch_artist=True,
                        showfliers=True)
        
        bp['boxes'][0].set_facecolor('lightblue')
        bp['boxes'][1].set_facecolor('lightcoral')
        
        ax.set_xticks([1, 2])
        ax.set_xticklabels(['APP', 'VOFF'])
        ax.set_ylabel(f'{title}' + (f' ({unit})' if unit else ''))
        ax.grid(alpha=0.3, axis='y')
        
        # Test estadístico
        stat, p = mannwhitneyu(data_app, data_voff, alternative='two-sided')
        
        # Anotar p-value
        y_max = max(data_app.max(), data_voff.max())
        sig_marker = '***' if p < 0.001 else '**' if p < 0.01 else '*' if p < 0.05 else 'ns'
        ax.text(1.5, y_max * 1.1, sig_marker, ha='center', fontsize=14, fontweight='bold')
        
        # Anotar medianas
        med_app = np.median(data_app)
        med_voff = np.median(data_voff)
        ax.text(1, med_app, f'{med_app:.2f}', ha='center', va='bottom', fontsize=9)
        ax.text(2, med_voff, f'{med_voff:.2f}', ha='center', va='bottom', fontsize=9)
    
    plt.suptitle('Temporal Coupling Analysis: APP vs VOFF (RC Regime)', 
                 fontsize=14, fontweight='bold', y=0.995)
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'temporal_coupling_comparison.png'), 
                dpi=150, bbox_inches='tight')
    print(f"✓ Guardado: temporal_coupling_comparison.png")
    plt.close()
    
    # ========================================================================
    # Figura 2: Phase lag distribution
    # ========================================================================
    
    fig, ax = plt.subplots(figsize=(10, 6))
    
    bins = np.arange(-20, 21, 1)
    ax.hist(df_app['opt_lag_cc'], bins=bins, alpha=0.6, label='APP', color='blue', edgecolor='black')
    ax.hist(df_voff['opt_lag_cc'], bins=bins, alpha=0.6, label='VOFF', color='red', edgecolor='black')
    
    ax.axvline(df_app['opt_lag_cc'].median(), color='blue', linestyle='--', linewidth=2, 
               label=f'APP median: {df_app["opt_lag_cc"].median():.1f}')
    ax.axvline(df_voff['opt_lag_cc'].median(), color='red', linestyle='--', linewidth=2,
               label=f'VOFF median: {df_voff["opt_lag_cc"].median():.1f}')
    
    ax.set_xlabel('Optimal Lag (ticks)', fontsize=12)
    ax.set_ylabel('Count', fontsize=12)
    ax.set_title('Distribution of Optimal Phase Lag (γ ↔ E_env)', fontsize=14, fontweight='bold')
    ax.legend()
    ax.grid(alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'phase_lag_distribution.png'), 
                dpi=150, bbox_inches='tight')
    print(f"✓ Guardado: phase_lag_distribution.png")
    plt.close()
    
    # ========================================================================
    # Figura 3: Information flow diagram
    # ========================================================================
    
    fig, ax = plt.subplots(figsize=(10, 6))
    
    te_E_gamma_app = df_app['te_E_to_gamma'].median()
    te_gamma_E_app = df_app['te_gamma_to_E'].median()
    te_E_gamma_voff = df_voff['te_E_to_gamma'].median()
    te_gamma_E_voff = df_voff['te_gamma_to_E'].median()
    
    x = np.arange(2)
    width = 0.35
    
    ax.bar(x - width/2, [te_E_gamma_app, te_gamma_E_app], width, 
           label='APP', color='lightblue', edgecolor='black')
    ax.bar(x + width/2, [te_E_gamma_voff, te_gamma_E_voff], width,
           label='VOFF', color='lightcoral', edgecolor='black')
    
    ax.set_ylabel('Transfer Entropy (bits)', fontsize=12)
    ax.set_title('Information Flow: Environment ↔ Agent', fontsize=14, fontweight='bold')
    ax.set_xticks(x)
    ax.set_xticklabels(['E_env → γ', 'γ → E_env'])
    ax.legend()
    ax.grid(alpha=0.3, axis='y')
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'information_flow.png'), 
                dpi=150, bbox_inches='tight')
    print(f"✓ Guardado: information_flow.png")
    plt.close()


# ============================================================================
# ESTADÍSTICAS
# ============================================================================

def print_statistics(df_app, df_voff):
    """
    Imprime estadísticas comparativas
    """
    print("\n" + "="*70)
    print("ESTADÍSTICAS COMPARATIVAS")
    print("="*70 + "\n")
    
    metrics = [
        ('opt_lag_cc', 'Optimal Lag (CC)'),
        ('max_corr_cc', 'Max Correlation'),
        ('max_mi', 'Max Mutual Info'),
        ('te_E_to_gamma', 'TE (E → γ)'),
        ('te_gamma_to_E', 'TE (γ → E)'),
        ('max_coherence', 'Max Coherence'),
        ('amplitude_ratio', 'Amplitude Ratio'),
    ]
    
    print(f"{'Metric':<25} {'APP':<20} {'VOFF':<20} {'p-value':<12} {'Effect'}")
    print("-"*90)
    
    for metric, name in metrics:
        app_vals = df_app[metric].values
        voff_vals = df_voff[metric].values
        
        app_mean = np.mean(app_vals)
        app_std = np.std(app_vals)
        voff_mean = np.mean(voff_vals)
        voff_std = np.std(voff_vals)
        
        stat, p = mannwhitneyu(app_vals, voff_vals, alternative='two-sided')
        
        # Cohen's d (effect size)
        pooled_std = np.sqrt((app_std**2 + voff_std**2) / 2)
        cohens_d = (app_mean - voff_mean) / (pooled_std + 1e-10)
        
        sig = '***' if p < 0.001 else '**' if p < 0.01 else '*' if p < 0.05 else 'ns'
        
        print(f"{name:<25} {app_mean:>7.3f}±{app_std:<5.3f}    {voff_mean:>7.3f}±{voff_std:<5.3f}    "
              f"{p:<7.4f} {sig:<4}  d={cohens_d:+.2f}")
    
    print("\n" + "="*70)
    print("INTERPRETACIÓN")
    print("="*70 + "\n")
    
    # Interpretación automática
    lag_diff = df_app['opt_lag_cc'].median() - df_voff['opt_lag_cc'].median()
    te_ratio = df_app['te_gamma_to_E'].median() / (df_voff['te_gamma_to_E'].median() + 1e-10)
    coh_diff = df_app['max_coherence'].median() - df_voff['max_coherence'].median()
    
    if abs(lag_diff) > 1:
        print(f"✓ Phase lag: APP es {abs(lag_diff):.1f} ticks {'más rápido' if lag_diff < 0 else 'más lento'} que VOFF")
        print(f"  → {'Tracking más eficiente' if lag_diff < 0 else 'Tracking más lento'}")
    
    if te_ratio > 1.5:
        print(f"\n✓ Active inference: APP muestra {te_ratio:.1f}× más flujo γ→E que VOFF")
        print(f"  → Agente activo, no solo reactivo")
    
    if coh_diff > 0.1:
        print(f"\n✓ Spectral coherence: APP +{coh_diff:.2f} vs VOFF")
        print(f"  → Mejor sincronización con frecuencia ambiental")


# ============================================================================
# MAIN
# ============================================================================

def main():
    parser = argparse.ArgumentParser(description='Análisis de acoplamiento temporal')
    parser.add_argument('--app_agents', required=True, help='Directorio con agentes APP')
    parser.add_argument('--voff_agents', required=True, help='Directorio con agentes VOFF')
    parser.add_argument('--app_ticks', required=True, help='Directorio con tick_data APP')
    parser.add_argument('--voff_ticks', required=True, help='Directorio con tick_data VOFF')
    parser.add_argument('--output_dir', default='temporal_analysis', help='Directorio de salida')
    parser.add_argument('--max_lag', type=int, default=20, help='Lag máximo para análisis')
    
    args = parser.parse_args()
    
    print("\n" + "="*70)
    print("ANÁLISIS DE ACOPLAMIENTO TEMPORAL")
    print("="*70 + "\n")
    
    # Analizar APP
    results_app = analyze_policy(args.app_agents, args.app_ticks, 'APP-Fixed', args.max_lag)
    
    # Analizar VOFF
    results_voff = analyze_policy(args.voff_agents, args.voff_ticks, 'VOFF', args.max_lag)
    
    if len(results_app) == 0 or len(results_voff) == 0:
        print("❌ No hay suficientes datos para análisis")
        return
    
    # Convertir a DataFrames
    df_app = pd.DataFrame(results_app)
    df_voff = pd.DataFrame(results_voff)
    
    # Guardar resultados
    os.makedirs(args.output_dir, exist_ok=True)
    df_app.to_csv(os.path.join(args.output_dir, 'temporal_metrics_APP.csv'), index=False)
    df_voff.to_csv(os.path.join(args.output_dir, 'temporal_metrics_VOFF.csv'), index=False)
    print(f"\n✓ Métricas guardadas en {args.output_dir}/")
    
    # Estadísticas
    print_statistics(df_app, df_voff)
    
    # Visualizaciones
    print("\n" + "="*70)
    print("GENERANDO VISUALIZACIONES")
    print("="*70 + "\n")
    plot_results(df_app, df_voff, args.output_dir)
    
    print("\n✅ Análisis completo")
    print(f"📁 Resultados en: {args.output_dir}/\n")


if __name__ == "__main__":
    main()
